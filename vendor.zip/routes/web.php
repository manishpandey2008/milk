<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController as Icontroller;
use App\Http\Controllers\PlantController as Pcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Route::get('/pandey', [App\Http\Controllers\HomeController::class, 'pandey'])->name('pandey');



////////////////// Home ///////////////

Route::group(['prefix'=>'/kubermilky'],function(){

	Route::GET('/index',[Icontroller::class, 'index'])->name('index');
	Route::GET('/contact',[Icontroller::class, 'contact'])->name('contact');
	Route::GET('/about',[Icontroller::class, 'about'])->name('about');

	Route::get('/login',[Icontroller::class, 'login'])->name('login');

	Route::post('/login',[Icontroller::class, 'loginVerification']);

});


/////////////////////// PLANT Work ////////////
Route::group(['prefix'=>'/kubermilky/plant'],function(){

	Route::GET('/{id}/home',[Pcontroller::class, 'home'])->name('plant.home');

		///////// create all ///////////
	Route::GET('/{id}/registration/{role}',[Pcontroller::class, 'registration'])->name('registration');
	Route::POST('/{id}/otpVerification/{role}',[Pcontroller::class, 'otpverification'])->name('otpverification');
	Route::GET('/{id}/details/{role}',[Pcontroller::class, 'details'])->name('details');
	Route::POST('/{role}/details',[Pcontroller::class, 'sendDetails'])->name('senddetails');
	Route::GET('/{id}/memberlist',[Pcontroller::class, 'memberList'])->name('memberlist');

	Route::GET('/{id}/logout',[Pcontroller::class, 'logout'])->name('plant.logout');
});


//////////////////////////   Society Work ////////////
Route::group(['prefix'=>'/kubermilky/society'],function(){


});

/////////////////////Farmer Work /////////////////////

Route::group(['prefix'=>'/kubermilky/farmer'],function(){

	
});


/////////////////////// Other Url/////////

Route::any('', function(){

	return "no page";
});