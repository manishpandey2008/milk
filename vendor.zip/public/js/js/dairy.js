$(document).ready(function(){
	$('#vill_name').on('click',function(){
		var vill_name=$(this).val();
		if(vill_name!='none')
		{
			$('#new_vill').hide();
		}
		else{
			$('#new_vill').show();
		}
	})
})