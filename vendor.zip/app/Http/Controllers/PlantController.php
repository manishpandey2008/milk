<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Registration;
use App\Models\Model\Create\Society;
use DB;
class PlantController extends Controller
{
     public function home(){

     	$work_role=session('role_of_work');
     	$id_of_user=session('id_of_user');
     	$users=Registration::all()->where('user_id',$id_of_user);

     	return view('plant.plantHome',[
     		'users'=>$users,
     	]);
     }

     public function registration($id,$role){
     	$work_role=session('role_of_work');
     	$id_of_user=session('id_of_user');
     	$users=Registration::all()->where('user_id',$id_of_user);
     	

     	return view('registration',[
     		'user_id'=>$id,
     		'users'=>$users,
     		'role'=>$role,
               'error'=>0,
     	]);
     }
     public function otpverification($id,$role){
     	$user=new Registration;

          $user->user_id=$role.'001';
          $user->remember_token=request('_token');
     	$user->plant_id=$id;	
     	$user->creater_user_id=$id;
     	$user->working_role=$role;
     	$user->first_name=request('first_name');
     	$user->mid_name=request('mid_name');
     	$user->last_name=request('last_name');

          $test_phone=Registration::where('phone_number',request('phone_number'))->count();
          if ($test_phone) {
               $error="This Phone Number Registerd";
               $users=Registration::all()->where('user_id',$id);
               return view('registration',[
                    'user_id'=>$id,
                    'users'=>$users,
                    'role'=>$role,
                    'error'=>$error,
                    ]);
          }

          $user->phone_number=request('phone_number');
     	$user->user_otp='1234';
     	$user->otp_conformation_status='0';
     	$user->email=request('email');
     	$user->user_photo="photo/manish.png";
     	$user->password=request('password');
     	$user->details_status='0';

     	$user->save();

          session(['create_work_role' => $role]);
          session(['create_user_id' => $user->user_id]);

          $users=Registration::all()->where('user_id',$id);

          return view('otpverification',[
               'users'=>$users,
               'role'=>$role,
               'user_id'=>$id,
               'error'=>0,
          ]);

     }


     public function details($id,$role){

          $users=Registration::all()->where('user_id',$id);

          $create_user_id=session('create_user_id');

           $otp=Registration::all()->where('user_id',$create_user_id)->where('user_otp',request('otp'))->count();

          if($role=="farmer")
          {
               if($otp)
               {
                    return view('create.farmerdetails',[
                    'users'=>$users,
                    'role'=>$role,
                    'user_id'=>$id,
                    'create_user_id'=>$create_user_id,
                    ]);
               }
               else{
                    $error="Enter Otp Is Wring";
                    return view('otpverification',[
                         'users'=>$users,
                         'role'=>$role,
                         'user_id'=>$id,
                         'error'=>$error,
                    ]);

               }
          }
          else if($role=="society")
          {
              
               if($otp)
               {
                    return view('create.societydetails',[
                    'users'=>$users,
                    'role'=>$role,
                    'user_id'=>$id,
                    'create_user_id'=>$create_user_id,
                    ]);
               }
               else{
                    $error="Enter Otp Is Wring";
                    return view('otpverification',[
                         'users'=>$users,
                         'role'=>$role,
                         'user_id'=>$id,
                         'error'=>$error,
                    ]);

               }
              
          }
          else if($role=="staff")
          {
                return view('',[

               ]);
          }
          else if($role=="bmc")
          {
                return view('',[

               ]);
          }
     }

     public function sendDetails($role){
         $id=session('create_user_id');
         $plant_id=session('id_of_user');
          if($role=="society")
          {
               $society=new Society;

               $bmc_id=request('bmc_id');
               if($bmc_id !='none')
               {
                 Registration::where('user_id',$id)->update('bmc_id',$bmc_id);
               }
               $society->user_id=$id;
               $society->plant_id=$plant_id;
               $society->society_system_type=request('society_system_type');
               $society->society_name=request('society_name');
               $society->name_hin=request('name_in_hindi');
               $society->father_name_eng=request('father_name');
               $society->father_name_hin=request('father_name_hindi');

               $village_name=request('village');
               $new_village_name=request('new_village');

               if($village_name !='none'){
                    $society->village_name=$village_name;
               }else{
                    $society->village_name=$new_village_name;
               }

               $society->address=request('full_address');
               $society->pin_code=request('pin_code');
               $society->gender=request('gender_name');
               $society->dob=request('dob');
               $society->anniversary_date=request('anniversaryDate');
               $society->emergency_contact_number=request('emergencyContactNumber');
               $society->blood_group=request('bloodGroup');
               $society->opening_balance_type=request('open_bal_type');
               $society->opening_amount=request('opening_amount');

               $society->payee_name=request('payee_name');
               $society->bank_name=request('bank_name');
               $society->account_number=request('act_name');
               $society->ifsc_code=request('ifsc_code');
               $society->aadhar_number=request('aadhar_number');
               $society->aadhar_card_doc=request('aadhar_doc');
               $society->photo=request('photo');
               $society->society_type=request('society_type');
               $society->payment_type=request('payment_type');
               $society->root_supervisor=request('supervisior');
               $society->commission_type=request('commission_type');
               $society->commission_amount=request('commission_val');

               $x=$society->save();

               if($x){
                    Registration::where('user_id',$id)->update(['details_status'=>'1']);
               }

          }
          

     }

     public function logout(){
     	session()->flush();
     	return redirect()->route('login',[
     		'error'=>0,
     	]);
     }

     


}
