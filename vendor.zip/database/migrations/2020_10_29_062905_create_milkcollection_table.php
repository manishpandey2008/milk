<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMilkcollectionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('milkcollection', function (Blueprint $table) {
            $table->id();
            $table->string('plant_id',30);
            $table->string('collection_id',30)->unique();
            $table->string('collection_from',50);
            $table->string('collection_from_user_id',30);
            $table->string('collection_to',50);
            $table->string('collection_to_user_id',30);
            $table->string('collection_shift',20);
            $table->string('milk_weight',20);
            $table->string('chart_category',20);
            $table->string('milk_snf',10);
            $table->string('milk_fat',10);
            $table->string('milk_clr',10);
            $table->string('milk_rate',10);
            $table->string('price',10);
            $table->string('collection_status',20);
            $table->string('collection_comment');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('milkcollection');
    }
}
